# Praesto — AI-Powered Multi-Asset Trading

This repository contains the **Praesto** whitepaper and supporting docs.

- Full whitepaper: [`WHITEPAPER.md`](./WHITEPAPER.md)
- Extra docs: [`docs/`](./docs/)
- Diagrams: [`diagrams/`](./diagrams/)
- Future smart contracts: [`contracts/`](./contracts/)

Praesto is the native token and incentive layer for the **Praesto trading platform** — a multi-market venue for **spot, perps, options and futures** over **crypto, forex and synthetic/tokenized stocks**.

## License
MIT
