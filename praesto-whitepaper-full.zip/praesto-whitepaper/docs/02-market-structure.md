# 02 – Market Structure

(spot, perps, options, futures; crypto/forex/synthetics)
