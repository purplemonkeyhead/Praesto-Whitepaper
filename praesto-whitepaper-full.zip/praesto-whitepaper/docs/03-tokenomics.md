# 03 – Tokenomics

This mirrors §6 of WHITEPAPER.md with 7,000,000,000 total supply and the 25/15/10/13/5/25/7 split.
