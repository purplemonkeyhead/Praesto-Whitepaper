# 04 – Staking & Stake-to-Autotrade

Flow: stake → pick strategy → grant bounded permission → AI executes → rewards.
