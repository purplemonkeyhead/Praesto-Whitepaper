# 05 – Governance

PRAESTO holders govern listings, risk, AI catalog and treasury via timelock.
