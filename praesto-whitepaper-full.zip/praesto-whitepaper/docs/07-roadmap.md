# 07 – Roadmap

Phases 0–3 as described in WHITEPAPER.md §12.
