# 06 – Security & Compliance

2+ audits, module isolation, oracle hardening, optional KYC on frontend.
