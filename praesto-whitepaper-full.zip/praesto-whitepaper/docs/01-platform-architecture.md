# 01 – Platform Architecture

(see WHITEPAPER.md §4 for the high-level version)
